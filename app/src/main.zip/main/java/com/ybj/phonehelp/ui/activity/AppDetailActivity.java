package com.ybj.phonehelp.ui.activity;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.ybj.phonehelp.R;
import com.ybj.phonehelp.base.AppComponent;
import com.ybj.phonehelp.base.BaseActivity;
import com.ybj.phonehelp.bean.ViewEvent;
import com.ybj.phonehelp.common.util.DensityUtil;
import com.ybj.phonehelp.ui.fragment.AppDetailFragment;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import butterknife.BindView;

/**
 * App详情页面
 * 如何让列表点击项突出显示
 * 通过透明度或者设置动画效果
 */

public class AppDetailActivity extends BaseActivity{

    private int mDatasBean;
    @BindView(R.id.rl)
    LinearLayout mRl;
    @BindView(R.id.content_view)
    FrameLayout mContentView;
    private boolean isInitFragment = false;
    private ObjectAnimator mAnimator;

    @Override
    public int setLayout() {
        return R.layout.activity_app_detail;
    }

    @Override
    public void setupActivityComponent(AppComponent appComponent) {
    }

    @Override
    public void init() {
        mDatasBean = getIntent().getIntExtra("appInfoId",0);
        //注册RxBus
        EventBus.getDefault().register(this);

    }

    /**
     * 接收数据
     */
    @Subscribe(threadMode = ThreadMode.MAIN, sticky = true)
    public void getView(ViewEvent view) {
        View view1 = view.getView();
        Bitmap bitmap = getViewImageCache(view1);
        if (bitmap != null) {
            mContentView.setBackgroundDrawable(new BitmapDrawable(bitmap));
        }

        int[] location = new int[2];
        //getLocationOnScreen():一个控件在整个屏幕中的位置
        view1.getLocationOnScreen(location);
        int left = location[0];
        int top = location[1];

        ViewGroup.MarginLayoutParams marginLayoutParams = new ViewGroup.MarginLayoutParams(mContentView.getLayoutParams());
        marginLayoutParams.topMargin = top - DensityUtil.getStatusBarH(this);
        marginLayoutParams.leftMargin = left;
        marginLayoutParams.width = view1.getWidth();
        marginLayoutParams.height = view1.getHeight();

        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(marginLayoutParams);
        mContentView.setLayoutParams(params);

        openInterfaceView();
    }

    /**
     * 获取View的缓存图像显示
     *
     * @param view
     * @return
     */
    private Bitmap getViewImageCache(View view) {
        view.setDrawingCacheEnabled(true);
        view.buildDrawingCache();
        Bitmap bitmap = view.getDrawingCache();
        if (bitmap == null) {
            return null;
        }
        bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight());

        view.destroyDrawingCache();

        return bitmap;
    }

    /**
     * 通过属性动画实现View向上下展开
     */
    public void openInterfaceView() {
        int height = DensityUtil.getScreenH(this) + DensityUtil.getStatusBarH(this);
        mAnimator = ObjectAnimator.ofFloat(mContentView, "scaleY", 1f, height);
        mAnimator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animation) {
                mContentView.setBackgroundColor(getResources().getColor(R.color.md_white_1000));
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                initFragment();
                isInitFragment = true;
            }

        });
        mAnimator.setStartDelay(500);
        mAnimator.setDuration(1000);
        mAnimator.start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //防止Activity的onDestroy()方法执行的时候，会初始化Fragment页面
        mAnimator.removeAllListeners();
        EventBus.getDefault().removeAllStickyEvents();
        EventBus.getDefault().unregister(this);
    }

    private void initFragment(){

        FragmentManager manager = getSupportFragmentManager();

        FragmentTransaction transaction = manager.beginTransaction();

        transaction.add(R.id.content_view,AppDetailFragment.newInstance(mDatasBean));
        transaction.commitAllowingStateLoss();
    }

}
