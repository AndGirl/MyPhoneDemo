package com.ybj.phonehelp.common.util;

/**
 * Created by wenmingvs on 2016/1/14.
 */
public class Features {
    public static int BGK_METHOD = 2;
    public static boolean showForeground = false;
}
