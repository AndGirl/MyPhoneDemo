package com.ybj.phonehelp.imageloader;

/**
 * @author Ivan
 */

public interface LoaderListener {

    void onSuccess();

    void onError();
}
