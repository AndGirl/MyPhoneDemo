package com.ybj.phonehelp.bean;

import android.view.View;

/**
 * Created by 杨阳洋 on 2018/2/22.
 */

public class ViewEvent {

    private View view;

    public View getView() {
        return view;
    }

    public ViewEvent(View view) {
        this.view = view;
    }
}
